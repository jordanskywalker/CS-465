const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path');

const dbURI = 'mongodb://127.0.0.1:27017/travlr';

mongoose.connect(dbURI);

require('./app_server/models/travlr');
const Trip = mongoose.model('trips');

const tripsPath = path.join(__dirname, 'app_server', 'data', 'trips.json');
const tripsData = JSON.parse(fs.readFileSync(tripsPath, 'utf8'));

mongoose.connection.on('connected', async () => {
  console.log(`Mongoose connected to ${dbURI}`);

  try {
    await Trip.deleteMany({});
    await Trip.insertMany(tripsData);
    console.log('Trip data loaded successfully');
  } catch (err) {
    console.log(err);
  } finally {
    mongoose.connection.close();
  }
});