const mongoose = require('mongoose');

const tripSchema = new mongoose.Schema({
    name: String,
    description: String,
    image: String
});

mongoose.model('Trip', tripSchema);