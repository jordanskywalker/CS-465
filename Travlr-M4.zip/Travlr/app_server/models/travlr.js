const mongoose = require('mongoose');

const tripSchema = new mongoose.Schema({
  name: { type: String, required: true },
  length: String,
  start: String,
  resort: String,
  perPerson: String,
  image: String,
  description: String
});

mongoose.model('trips', tripSchema);