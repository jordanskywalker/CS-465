const trips = require('../data/trips.json');

const renderPage = (view, page, title, extraData = {}) => (req, res) => {
  res.render(view, {
    title,
    isHome: page === 'home',
    isTravel: page === 'travel',
    isRooms: page === 'rooms',
    isMeals: page === 'meals',
    isNews: page === 'news',
    isAbout: page === 'about',
    isContact: page === 'contact',
    ...extraData
  });
};

module.exports = {
  home: renderPage('index', 'home', 'Travlr Getaways Website Template'),
  travel: renderPage('travel', 'travel', 'Travel - Travlr Getaways Website Template', { trips }),
  rooms: renderPage('rooms', 'rooms', 'Rooms - Travlr Getaways Website Template'),
  meals: renderPage('meals', 'meals', 'Meals - Travlr Getaways Website Template'),
  news: renderPage('news', 'news', 'News - Travlr Getaways Website Template'),
  about: renderPage('about', 'about', 'About - Travlr Getaways Website Template'),
  contact: renderPage('contact', 'contact', 'Contact - Travlr Getaways Website Template')
};