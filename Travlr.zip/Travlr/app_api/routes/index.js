const express = require('express');
const router = express.Router();
const ctrlTrips = require('../controllers/trips');
const auth = require('../controllers/authentication');
const authMiddleware = require('../middleware/auth');

router.post('/login', auth.login);

router
  .route('/trips')
  .get(ctrlTrips.tripsList)
  .post(authMiddleware, ctrlTrips.tripsAddTrip);

router
  .route('/trips/:tripCode')
  .get(ctrlTrips.tripsFindByCode)
  .put(authMiddleware, ctrlTrips.tripsUpdateTrip)
  .delete(authMiddleware, ctrlTrips.tripsDeleteTrip);

module.exports = router;