const jwt = require('jsonwebtoken');

const authenticate = (req, res, next) => {
  const header = req.headers.authorization;

  if (!header) {
    return res.status(401).json({ message: 'No token' });
  }

  const token = header.split(' ')[1];

  try {
    jwt.verify(token, 'MY_SECRET_KEY');
    next();
  } catch {
    res.status(401).json({ message: 'Invalid token' });
  }
};

module.exports = authenticate;