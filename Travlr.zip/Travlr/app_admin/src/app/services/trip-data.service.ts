import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Trip } from '../models/trip';

@Injectable({
  providedIn: 'root'
})
export class TripDataService {
  private apiURL = '/api';

  constructor(private http: HttpClient) {}

  private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem('token') || '';
    return new HttpHeaders({
      Authorization: `Bearer ${token}`
    });
  }

  public getTrips(): Observable<Trip[]> {
    return this.http.get<Trip[]>(`${this.apiURL}/trips`);
  }

  public getTrip(code: string): Observable<Trip> {
    return this.http.get<Trip>(`${this.apiURL}/trips/${code}`);
  }

  public addTrip(trip: Trip): Observable<Trip> {
    return this.http.post<Trip>(`${this.apiURL}/trips`, trip, {
      headers: this.getAuthHeaders()
    });
  }

  public updateTrip(code: string, trip: Trip): Observable<Trip> {
    return this.http.put<Trip>(`${this.apiURL}/trips/${code}`, trip, {
      headers: this.getAuthHeaders()
    });
  }

  public deleteTrip(code: string): Observable<any> {
    return this.http.delete(`${this.apiURL}/trips/${code}`, {
      headers: this.getAuthHeaders()
    });
  }
}