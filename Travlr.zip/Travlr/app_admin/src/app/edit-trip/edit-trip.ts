import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { TripDataService } from '../services/trip-data.service';
import { Trip } from '../models/trip';

@Component({
  selector: 'app-edit-trip',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './edit-trip.html',
  styleUrl: './edit-trip.css'
})
export class EditTrip implements OnInit {
  trip: Trip = {
    code: '',
    name: '',
    length: '',
    start: '',
    resort: '',
    perPerson: '',
    image: '',
    description: ''
  };

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private tripService: TripDataService
  ) {}

  ngOnInit(): void {
    const code = this.route.snapshot.paramMap.get('code');
    if (code) {
      this.tripService.getTrip(code).subscribe({
        next: (data) => {
          this.trip = Array.isArray(data) ? data[0] : data;
        },
        error: (err) => {
          console.log('LOAD ERROR:', err);
        }
      });
    }
  }

  onSubmit(): void {
    this.tripService.updateTrip(this.trip.code, this.trip).subscribe({
      next: () => {
        this.router.navigate(['/']);
      },
      error: (err) => {
        console.log('UPDATE ERROR:', err);
      }
    });
  }

  onDelete(): void {
    this.tripService.deleteTrip(this.trip.code).subscribe({
      next: () => {
        this.router.navigate(['/']);
      },
      error: (err) => {
        console.log('DELETE ERROR:', err);
      }
    });
  }
}