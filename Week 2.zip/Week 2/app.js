const express = require('express');
const path = require('path');
const hbs = require('hbs');

const app = express();
const routes = require('./app_server/routes/index');

app.set('views', path.join(__dirname, 'app_server', 'views'));
app.set('view engine', 'hbs');

app.use(express.static(path.join(__dirname, 'public')));
app.use('/', routes);

const port = 3000;

app.listen(port, () => {
    console.log(`App running on port ${port}`);
});