const home = (req, res) => {
    res.render('home', {
        title: 'Home',
        message: 'Welcome to Travlr'
    });
};

const traveler = (req, res) => {
    res.render('traveler', {
        title: 'Traveler Page',
        message: 'This is the traveler page'
    });
};

module.exports = {
    home,
    traveler
};