const express = require('express');
const path = require('path');
const hbs = require('hbs');
require('./app_api/models/db');

const app = express();

// view engine setup
app.set('views', path.join(__dirname, 'app_server', 'views'));
app.set('view engine', 'hbs');

// register partials
hbs.registerPartials(path.join(__dirname, 'app_server', 'views', 'partials'));

// middleware
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

// routes
const routes = require('./app_server/routes/index');
const apiRouter = require('./app_api/routes/index');

app.use('/', routes);
app.use('/api', apiRouter);

// start server
const port = 3000;
app.listen(port, () => {
  console.log(`App running on port ${port}`);
});