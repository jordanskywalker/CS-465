const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path');

const dbURI = 'mongodb://127.0.0.1:27017/travlr';

require('../../app_api/models/travlr');
const Trip = mongoose.model('trips');

const tripsPath = path.join(__dirname, '..', 'data', 'trips.json');

async function seedDB() {
  try {
    await mongoose.connect(dbURI);
    console.log(`Connected to ${dbURI}`);

    const rawData = fs.readFileSync(tripsPath, 'utf8');
    const tripsData = JSON.parse(rawData);

    console.log('Trips file path:', tripsPath);
    console.log('Trips loaded from file:', tripsData.length);

    await Trip.deleteMany({});
    console.log('Old trips deleted');

    const inserted = await Trip.insertMany(tripsData);
    console.log('Trips inserted:', inserted.length);
  } catch (err) {
    console.error('SEED ERROR:', err);
  } finally {
    await mongoose.connection.close();
    console.log('Database connection closed');
  }
}

seedDB();