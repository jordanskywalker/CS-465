const renderPage = (view, page, title, extraData = {}) => (req, res) => {
  res.render(view, {
    title,
    isHome: page === 'home',
    isTravel: page === 'travel',
    isRooms: page === 'rooms',
    isMeals: page === 'meals',
    isNews: page === 'news',
    isAbout: page === 'about',
    isContact: page === 'contact',
    ...extraData
  });
};

const home = renderPage('index', 'home', 'Travlr Getaways Website Template');
const rooms = renderPage('rooms', 'rooms', 'Rooms - Travlr Getaways Website Template');
const meals = renderPage('meals', 'meals', 'Meals - Travlr Getaways Website Template');
const news = renderPage('news', 'news', 'News - Travlr Getaways Website Template');
const about = renderPage('about', 'about', 'About - Travlr Getaways Website Template');
const contact = renderPage('contact', 'contact', 'Contact - Travlr Getaways Website Template');

const travel = async (req, res) => {
  const tripsEndpoint = 'http://localhost:3000/api/trips';
  const options = {
    method: 'GET',
    headers: {
      Accept: 'application/json'
    }
  };

  try {
    const response = await fetch(tripsEndpoint, options);
    const json = await response.json();

    if (!Array.isArray(json)) {
      return res.status(500).send('API lookup error');
    }

    if (json.length === 0) {
      return res.status(404).send('No trips found');
    }

    res.render('travel', {
      title: 'Travel - Travlr Getaways Website Template',
      isHome: false,
      isTravel: true,
      isRooms: false,
      isMeals: false,
      isNews: false,
      isAbout: false,
      isContact: false,
      trips: json
    });
  } catch (err) {
    res.status(500).send(err.message);
  }
};

module.exports = {
  home,
  travel,
  rooms,
  meals,
  news,
  about,
  contact
};